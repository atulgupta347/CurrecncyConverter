import requests
from tkinter import *
import tkinter as tk
from tkinter import ttk

# Read the all the currencies rate wrt to Base currency i.e. INR
# Convert the amount as per the currencies
class ConvertCurrency():
    def __init__(self,url):
        self.data=requests.get(url).json()
        self.currencies=self.data["rates"]

    def Convertor(self,from_Currency,to_Currency,amount):
        #Firstly, convert the currency to default base.
        amount=amount/self.currencies[from_Currency]
        #Return the converted amount upto 2 decimals
        return round(amount*self.currencies[to_Currency],2)

#Currency Convertor GUI
class ConvertCurrencyGUI(tk.Tk):
    def __init__(self,converter):
        tk.Tk.__init__(self)

        # GUI configuration
        self.converter=converter
        self.geometry("500x300")
        self.title("CurrencyConverter")
        self.maxsize(500,300)
        self.configure(bg='white')

        #Default From and To Currencies
        from_curr="INR"
        to_curr="USD"

        #Header Configuration
        self.intro_label = Label(self, text = 'Currency Convertor',  fg = 'orange', relief = tk.FLAT, bg='white')
        self.intro_label.config(font = ('Helvetica',20,'bold'))
        self.intro_label.place(relx = 0.32,rely = 0)

        # Real Time Default currencies configuration
        self.date_label = Label(self,
                                text=f"1 {from_curr} = {self.converter.Convertor(from_curr, to_curr, 1)} {to_curr} \n Date : {self.converter.data['date']}",
                                relief=tk.FLAT, fg='orange', bg='white')
        self.intro_label.config(font=('Helvetica', 15, 'bold'))
        self.date_label.place(relx=0.40, rely=0.15)

        #restrictNumberOnly function will restrict the user to enter invalid number in Amount field.
        valid = (self.register(self.restrictNumberOnly), '%d', '%P')

        # Currencies dropdown
        self.from_currency_variable = StringVar(self)
        self.from_currency_variable.set(from_curr)
        self.to_currency_variable = StringVar(self)
        self.to_currency_variable.set(to_curr)

        font = ("Helvetica", 12, "bold")
        self.option_add('*TCombobox*Listbox.font', font)
        self.from_currency_dropdown = ttk.Combobox(self, textvariable=self.from_currency_variable,
                                                   values=list(self.converter.currencies.keys()), font=font,
                                                   state='readonly', width=12, justify=tk.CENTER,foreground='orange')
        self.from_currency_dropdown.place(x=30, y=120)
        self.to_currency_dropdown = ttk.Combobox(self, textvariable=self.to_currency_variable,
                                                 values=list(self.converter.currencies.keys()), font=font,
                                                 state='readonly', width=12, justify=tk.CENTER,foreground='orange')
        self.to_currency_dropdown.place(x=340, y=120)

        #Fields
        self.amount_field = Entry(self, bd=3, relief=tk.RIDGE, justify=tk.CENTER, validate='key', validatecommand=valid,fg = 'orange')
        self.amount_field.place(x=32, y=150)
        self.converted_amount_field_label = Label(self, text='', fg='orange', bg='white', relief=tk.RIDGE,
                                                  justify=tk.CENTER, width=17, borderwidth=3)
        self.converted_amount_field_label.place(x=342, y=150)


        # Convert button
        self.convert_button = Button(self, text="Convert", fg="orange", command=self.perform)
        self.convert_button.config(font=('Helvetica', 15, 'bold'))
        self.convert_button.place(x=210, y=175)

    #perform the calculation
    def perform(self):
            #Get the user inputs
            if self.amount_field.get()!='':
                amount = float(self.amount_field.get())
                from_curr = self.from_currency_variable.get()
                to_curr = self.to_currency_variable.get()

                converted_amount = self.converter.Convertor(from_curr, to_curr, amount)
                converted_amount = round(converted_amount, 2)

                #update the converted amount
                self.converted_amount_field_label.config(text=str(converted_amount))

                # Real Time currency configuration
                self.date_label = Label(self,
                                        text=f"1 {from_curr} = {self.converter.Convertor(from_curr, to_curr, 1)} {to_curr} \n Date : {self.converter.data['date']}",
                                        relief=tk.FLAT, fg='orange', bg='white')
                self.intro_label.config(font=('Helvetica', 15, 'bold'))
                self.date_label.place(relx=0.40, rely=0.15)

    #validate the user input
    def restrictNumberOnly(self, action, string):
            regex = re.compile(r"[0-9,]*?(\.)?[0-9,]*$")
            result = regex.match(string)
            return (string == "" or (string.count('.') <= 1 and result is not None))


if __name__ =="__main__":
    #URL to get the real time currencies rates
    url="https://api.exchangerate-api.com/v4/latest/INR"
    converter=ConvertCurrency(url)
    ConvertCurrencyGUI(converter)
    mainloop()